<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="robots" content="noindex, nofollow">
      <title>Product Shopping Grid</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
      <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	  <link href="css/style.css" rel="stylesheet">

   </head>
   <body <?php // echo $loadFun?>>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
      <div class="container">
         <h3 class="h3">Service provider</h3>
         <input type="hidden" name="csrf-token" id="csrf-token" value="<?php echo e(csrf_token()); ?>">
         <?php if($data): ?>
                <h4>City Name: <?php echo e($data->cityName); ?></h4>
            <?php endif; ?>
         <div class="row" id="product_id">
       
         </div>
      </div>
   </body>
</html>
<script>
if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function (position) {
        console.log(position);
        var lat = position.coords.latitude;
        var lng = position.coords.longitude;
        var csrf = $("#csrf-token").val();
        $.ajax({
            url:'/getgeo',
            type:'post',
            data:{ _token:  csrf,latitude:lat,longitude:lng},
            success:function(aData)
            {
                $html = '';
                if(aData.success == 1){
                    $.each(aData.data, function(k, v) {
                       $html += ' <div class="col-md-6 col-sm-6"><div class="card"><div class="card-body"><div class="product-grid"><div class="product-image"><a href="#"></a> </div><div class="product-content"><h3 class="title"><a href="#"> Service provider Name :'+ v.name + '</br>( Email :' + v.Email +')</a></h3> <h3 class="title"><a href="#">'+ v.phone + '</a></h3> <div class="distance"> '+Math.round(v.distance * 100) / 100+' KM </div> </div> </div> </div>  </div> </div>';
                    });
                    $("#product_id").append($html);
                }
            }

        });
    });
}
</script><?php /**PATH D:\xampp\htdocs\webcaste\resources\views/welcome.blade.php ENDPATH**/ ?>