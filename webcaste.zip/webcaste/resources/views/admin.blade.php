<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="robots" content="noindex, nofollow">
      <title> Service provider </title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
      <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	  <link href="css/style.css" rel="stylesheet">
   </head>
   <body <?php // echo $loadFun?>>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
      <div class="container">
         <h3 class="h3">Service provider</h3>
         <input type="hidden" name="csrf-token" id="csrf-token" value="{{ csrf_token() }}">
         @if($data)
                <h4>City Name: {{ $data->cityName }}</h4>
            @endif
         <?php if(!empty($message)) { ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong> Successfully inserted!</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
         <?php } ?>
            
        
         <form action="/admin_form" method="post">
         @csrf
            <div class="form-group">
                <label for="exampleInputEmail1">Name</label>
                <input type="name" class="form-control" id="name" name="name" aria-describedby="emailHelp" placeholder="Enter name" required>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Email</label>
                <input type="Email" class="form-control"  name="Email"  id="Email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Phone</label>
                <input type="number" class="form-control" name="phone" id="phone" placeholder="phone" required>
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">latitude </labe l>
                <input type="text"   name="latitude" value="{{$data->latitude }}" class="form-control"  >
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">longitude  </label>
                <input type="text"   name="longitude" value="{{$data->longitude }}"class="form-control"  >
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        
      </div>
   </body>
</html>