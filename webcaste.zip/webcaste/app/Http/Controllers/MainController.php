<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stevebauman\Location\Facades\Location;
use DB;
use Session;

class MainController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $ip = gethostbyaddr($_SERVER["REMOTE_ADDR"]); 
        $data = Location::get($ip);
        return view('welcome',['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getgeo(Request $request)
    {
            if(isset($request->latitude) && isset($request->longitude)){
                $lat=$request->latitude;
                $lon=$request->longitude;
                $res=DB::select("SELECT provider.*, (3959 * acos (cos ( radians('$lat') ) * cos( radians( provider.latitude ) ) * cos( radians( provider.longitude ) - radians('$lon') ) + sin ( radians('$lat') ) * sin( radians( provider.latitude ) ))) AS distance FROM provider ORDER BY distance");
                return [ 'success' => 1, 'data' => $res,  'msg' => 'succesfully'];
            }else{
                $res=DB::select("select * from provider");
                return [ 'success' => 1, 'data' => $res,  'msg' => 'succesfully'];
            
            }
 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function admin()
    {
         $ip = gethostbyaddr($_SERVER["REMOTE_ADDR"]); 
        $data = Location::get($ip);
        return view('admin',['data' => $data]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function admin_form(Request $request)
    {
        DB::table('provider')->insert(
            [   
                'name'		=> $request->input('name'),
                'Email'		=> $request->input('Email'),
                'phone'		=> $request->input('phone'),
                'longitude'		=> $request->input('longitude'),
                'latitude'		=> $request->input('latitude'),
                'status'		=> 'submit'
            
        ]);
        
        $ip = gethostbyaddr($_SERVER["REMOTE_ADDR"]); 
        $data = Location::get($ip);
        return view('admin',['data' => $data, 'message'=> 'successfully insert']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
